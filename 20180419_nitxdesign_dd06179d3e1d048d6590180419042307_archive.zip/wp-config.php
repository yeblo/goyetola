<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'practice');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'wa/y|PvbI^F`;o)3MeUGx6ke_hyh;MkK>>5ca>TY+og?<J4d/g?AQ,h`Nd,._*jK');
define('SECURE_AUTH_KEY',  'h+stNGS=yG|[>CMtm)eZU[g1_(*9Jcp1Pvh:kd)XXt{I,IL6P?*bdpD^jape{mRY');
define('LOGGED_IN_KEY',    'a}N~X+V]kt_,DsM+Z`(MkjH7*dUIJ6J&}7CvYx~e04GS~EG6X)Y6M^E@h1.~EFz6');
define('NONCE_KEY',        'q`,QWHA(<V#~U=J=M+_}3(Rq ls^r8x=8jW.(6p/T6MYu$Hc.p^@k22$(O9W|cVm');
define('AUTH_SALT',        'PuGE<<PL+_6gmi~X>=~;-MmgUyLNBx~Z8kRP&YYurQ[!9rU<&+[}H-v(7ZzI +K!');
define('SECURE_AUTH_SALT', '%*2EaJ!1wbkR%N b/6dV$qn vy%-cHtkY1mh^4,_34L]C4zy<iTeLg{NEsxyJmuc');
define('LOGGED_IN_SALT',   '=DnzrhFAP-k0:6u<HPYzrZq&<R?L;P3{*,e/P[:I[W70TiL1S##1AL=*2$p93tNP');
define('NONCE_SALT',       '2iPc$yu>=M,e3-`/C;N%Wl_vH*:13{/oEe$8W>,93*xNydv|jZr$CFhq`D^ou~.F');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp342345_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
